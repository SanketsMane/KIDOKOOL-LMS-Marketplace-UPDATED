"use client";

import { FindTeacherContent } from "@/components/mentors/FindTeacherContent";

export default function MarketplacePage() {
  return <FindTeacherContent />;
}
