"use client";

import { FindTeacherContent } from "@/components/mentors/FindTeacherContent";

export default function DashboardMentorsPage() {
    return <FindTeacherContent />;
}
